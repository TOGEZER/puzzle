<?php 
/*
	Define all plugin information 
*/	

	$plugin_name = "User Shortcodes - Lites";
	$plugin_slug = "usershortcodes";
	
	$menu_name = "User Shortcodes";
	$menu_slug = "usershortcodes";	

	$plugin_version = "1.0.0";
	$plugin_website = "http://happyplugins.com/user-shortcodes";
	$author_name = "HappyPlugins";
	$author_website = "http://happyplugins.com";
	
	$pro_upgrade_url ="http://happyplugins.com/user-shortcodes-pro";
	
	$changelog_url = "http://happyplugins.com/user-shortcodes";

?>