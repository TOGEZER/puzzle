<?php 

/*
	Create Administration menus
*/


class user_shortcodes_menus {

	function __construct (){
	
		
	
	
	}
	
	
	
	function add_menus (){
	
	
	
	}
	
	
	function add_style (){
	
	
	
	}




}







?>